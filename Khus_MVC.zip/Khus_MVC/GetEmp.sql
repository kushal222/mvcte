 procedure  Emp_Detail_Get
   (
     
      O_result out cursorsearch
      
   )
   as
   begin
   Open O_result For
   select  e.empid EmpID  , e.name Name,e.age Age, E.MARITALSTATUS MaritalStatus from MVC_EMPTBLE e  ;
   end Emp_Detail_Get;
