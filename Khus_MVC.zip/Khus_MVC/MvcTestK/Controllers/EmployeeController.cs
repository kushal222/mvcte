﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcTestK.Models;

namespace MvcTestK.Controllers
{
    public class EmployeeController : Controller
    {
        //
        // GET: /Employee/

        public ActionResult Index()
        {
            EmplyoeeDataCls obj = new EmplyoeeDataCls();

           
            return View(obj.GetEmpRecord());
        }



        public ActionResult Delete(string  ID)
        {

            try
            {
                EmplyoeeDataCls ItemHandler = new EmplyoeeDataCls();
                if (ItemHandler.Delete(ID))
                {
                    ViewBag.AlertMsg = "Item Deleted Successfully";
                }
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }

          
        }


       






    }
}
