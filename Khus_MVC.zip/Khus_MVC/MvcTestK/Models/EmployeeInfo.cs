﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcTestK.Models
{
    public class EmployeeInfo
    {

        public string EmpID { get; set; }

        public string Name{ get; set; }

        public string Age { get; set; }

        public string  MaritalStatus { get; set; }

        public string Salary { get; set; }

        public string Location { get; set; }

     
    }
}