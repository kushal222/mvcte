﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.OracleClient;
using System.Configuration;

namespace MvcTestK.Models
{
    public class EmplyoeeDataCls
    {


        public List<EmployeeInfo> GetEmpRecord()
        {
            List<EmployeeInfo> iList = new List<EmployeeInfo>();
            DataTable dt = new DataTable();

            string strcon = ConfigurationManager.ConnectionStrings["staging_ed"].ConnectionString;
            DataSet ds = new DataSet();
            OracleConnection con = new OracleConnection(strcon);
            OracleCommand cmd = new OracleCommand("PKG_MVC.Emp_Detail_Get", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("O_result", OracleType.Cursor).Direction = ParameterDirection.Output;
            OracleDataAdapter da = new OracleDataAdapter(cmd);
            con.Open();
            da.Fill(dt);
            con.Close();

            foreach (DataRow dr in dt.Rows)
            {
                iList.Add(new EmployeeInfo
                {
                    EmpID = Convert.ToString(dr["EMPID"]),
                    
                    Name = Convert.ToString(dr["NAME"]),
                    Age = Convert.ToString(dr["AGE"]),
                    MaritalStatus = Convert.ToString(dr["MARITALSTATUS"])
                });
            }
            return iList;
        }


         //added by 


        public bool Delete(string  ID)
        {
            string strcon = ConfigurationManager.ConnectionStrings["staging_ed"].ConnectionString;
            OracleConnection con = new OracleConnection(strcon);
            OracleCommand cmd = new OracleCommand("PKG_MVC.Emp_MVCTBLE_DeleteRecord", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("P_EMP_ID", ID);
            cmd.Parameters.Add("O_RESULT", OracleType.Cursor).Direction = ParameterDirection.Output;
            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();

            if (i >= 1)
                return true;
            else
                return false;
        }




        //saerch


        //public bool   Search(string Age)
        //{
        //    string strcon = ConfigurationManager.ConnectionStrings["staging_ed"].ConnectionString;
        //    OracleConnection con = new OracleConnection(strcon);
        //    OracleCommand cmd = new OracleCommand("PKG_MVC.Emp_MVCTBLE_SearchRecord", con);
        //    cmd.CommandType = CommandType.StoredProcedure;
        //    cmd.Parameters.Add("P_Age", Age);
        //    cmd.Parameters.Add("O_RESULT", OracleType.Cursor).Direction = ParameterDirection.Output;
        //    con.Open();
        //    int i = cmd.ExecuteNonQuery();
        //    con.Close();

        //    if (i >= 1)
        //        return true;
        //    else
        //        return false;
        //}





    }
}